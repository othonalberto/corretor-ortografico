bool boaSugestao(std::string original, std::string sugestao);
